#include <stdio.h>
int main()
{
do
{
    printf("I M HERE\n");
}
while(1<1);
    return 0;
}