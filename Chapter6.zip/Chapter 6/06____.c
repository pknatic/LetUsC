#include <stdio.h>
int main()
{
int i,j;
for(i=1,j=1;j<=10 && i<=15;j++,i++)
printf("i = %d j = %d \n",i,j);
    return 0;
}